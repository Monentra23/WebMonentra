# MONENTRA Demo

Template full-stack untuk portal pengajuan dengan login user/admin, upload dokumen, dashboard, activity log, dan titik integrasi Google Sheets/Discord.

## Jalankan
1. Install Node.js 18+.
2. `npm install`
3. Salin `.env.example` menjadi `.env`.
4. Isi `SESSION_SECRET`, `ADMIN_ID`, dan `ADMIN_PASSWORD_HASH`.
5. Buat hash password admin, contoh:
   `node -e "const b=require('bcryptjs'); b.hash('GantiPasswordKuat',12).then(console.log)"`
6. `npm start`
7. Buka `http://localhost:3000`.
8. Admin: `http://localhost:3000/admin-login.html`.

## Google Sheets & Discord
Backend sudah memiliki titik konfigurasi `.env`, tetapi konektor Google Sheets dan Discord perlu diimplementasikan sesuai akun/project Anda sebelum produksi. Jangan taruh credential di frontend.

## Catatan produksi
Data aplikasi saat ini disimpan in-memory sebagai demo sehingga akan hilang saat server restart. Untuk produksi gunakan database persisten. File upload disimpan lokal dan perlu storage privat/retention policy yang sesuai. Jangan gunakan demo ini sebagai sistem produksi tanpa audit keamanan, legal/privacy review, dan konfigurasi penyimpanan yang tepat.
